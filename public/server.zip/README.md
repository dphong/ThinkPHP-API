# SERVER

### 运行

```
npm run start
```

在浏览器中输入localhost:3000打开即可

返回数据

```
{
    success: true,
    name: name
}
```